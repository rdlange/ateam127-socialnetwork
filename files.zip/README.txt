README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. member name1, lecture, and email1@wisc.edu
2. member name2, lecture, and email2@wisc.edu
3. member name3, lecture, and email3@wisc.edu
4. member name4, lecture, and email4@wisc.edu

Notes or comments to the grader:

[place any comments or notes that will help the grader here]


